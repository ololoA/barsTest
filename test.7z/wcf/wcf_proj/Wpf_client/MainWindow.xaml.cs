﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf_client
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        class Table 
        { 
            public Table(bool flag, string date, int number, string dateOfLast)
            {
                this.relevance = flag;
                this.date = date;
                this.number = number;
                this.dateOfLast = dateOfLast;
            }
            public bool relevance { get; set; }
            public string date { get; set; }
            public int number { get; set; }
            public string dateOfLast { get; set; }

        }
       
        ServiceForBase.ServiceForBaseClient client; 
        public MainWindow()
        {
            InitializeComponent();
            client = new ServiceForBase.ServiceForBaseClient();
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            List<ServiceForBase.DataBD> result = new List<ServiceForBase.DataBD>();
            List<Table> table = new List<Table>();
            result = client.GetAll().ToList();
            bool flag = true;
            foreach (var item in result)
            {
                if ((DateTime.Now.Subtract(item.dateOfLastUpdate).TotalDays) <= 60)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
                table.Add(new Table(flag, item.date.ToShortDateString(), item.number, item.dateOfLastUpdate.ToShortDateString()));
               
            }
            
            DataGrid.ItemsSource = table;
            
        }
    }
}
