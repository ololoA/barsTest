﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace wcf_proj
{
    // ПРИМЕЧАНИЕ. Команду "Переименовать" в меню "Рефакторинг" можно использовать для одновременного изменения имени класса "ServiceForBase" в коде и файле конфигурации.
   [ServiceBehavior]
    public class ServiceForBase : IServiceForBase
    {
        string connString= @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=E:\барс\херня\wcf\wcf_proj\wcf_proj\DatabaseContracts.mdf;Integrated Security = True";
        public List<DataBD> GetAll()
        {
            string query = "SELECT Date, Number, DateLastUpdate FROM [Contracts]";
            SqlConnection cn;
            SqlCommand command;// = new SqlCommand(query, connString);
            cn = new SqlConnection(connString);
            cn.Open();

            command = cn.CreateCommand();
            command.CommandText = query;
            SqlDataReader dataReader = command.ExecuteReader();

            List<DataBD> products = new List<DataBD>();
            while (dataReader.Read())
            {
                products.Add(new DataBD()
                {
                    number = dataReader.GetInt32(1),
                    date = dataReader.GetDateTime(0),
                    dateOfLastUpdate = dataReader.GetDateTime(2),
                });
            }
            cn.Close();
            return products;
        }

    }
}
