﻿CREATE TABLE [dbo].[Contracts]
(
    [Date] DATE NULL, 
    [Number] INT NOT NULL, 
    [DateLastUpdate] DATE NULL, 
    CONSTRAINT [PK_Contracts] PRIMARY KEY ([Number])
)
